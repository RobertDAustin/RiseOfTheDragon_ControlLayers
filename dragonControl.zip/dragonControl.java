
    package byui.cit260.curiousworksmenship.control;
	
	public class dragonControl {
	
	    public double rideOnDragon(double player, double inventory) {
		
		    if (player < 0) { //player is negative?
			    RETURN -1
			}
			
			if (inventory < 0 || inventory > 42) { //inventory out of range?
			    RETURN -1
			}

			double weight = (player + inventory)
			
			return ride;
		}
	
	}