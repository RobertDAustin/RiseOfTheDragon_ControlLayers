
    package byui.cit260.curiousworksmenship.control;
	
	public class mapControl {
	
	    public double move(double actor, double location) {
		
		    if (actor < 0) { //actor is negative?
			    RETURN -1
			}
			
			if (location < 0 || location > 2) { //location out of range?
			    RETURN -1
			}

			double change = (location / actor)
			
			return movement;
		}
	
	}